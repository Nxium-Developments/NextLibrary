Execute the start.bat file to run NextLanguage, to read your file, run the command "node app.js <your .nxl file>" if it does not work, please use "cd NextLanguage"
to go to the libary folder and executes it. Or just run and build your code in the NextLanguage Folder.


Thank you!